<!DOCTYPE html>
<html lang="<?php language_attributes(); ?>">

<head>
  <meta charset="<?php bloginfo('charset');?>">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title><?php bloginfo();?></title>
  <meta content="" name="description">
  <meta content="" name="keywords">
  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Raleway:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">
  <?php wp_head();?>
</head>

<body>

  <!-- ======= Mobile nav toggle button ======= -->
  <i class="bi bi-list mobile-nav-toggle d-xl-none"></i>

  <!-- ======= Header ======= -->
  <header id="header">
    <div class="d-flex flex-column">
    <?php 
                        $prf_data = get_field('profile_data','option');
                            $prf_img = $prf_data['ptofile_image'];
                            $prf_name = $prf_data['name'];
                            $prf_desg = $prf_data['designation'];

                        ?>
                       
      <div class="profile">
      <?php if($prf_data):?>
        <img src="<?php echo $prf_img['url']; ?>" alt="" class="img-fluid rounded-circle">
        <h1 class="text-light"><a href="<?php echo home_url(); ?>"><?php echo $prf_name;?></a></h1>
        <h4 class="text-white text-center"><?php echo $prf_desg;?></h4>
        <?php endif; ?>
        <?php 
                             $social = get_field('social_icons','option');
                             if( $social ) {?>
        <div class="social-links mt-3 text-center">
        <?php foreach( $social as $row ) {
                                        $s_name = $row['social_name'];
                                        $s_url = $row['social_url'];
                                    ?>
          <a href="<?php echo $s_url; ?>" target="_blank" class="<?php echo $s_name; ?>"><i class="<?php echo 'bx bxl-' . $s_name; ?>"></i></a>
          <?php }?>
        </div>
        <?php }?>
      </div>

      <nav id="navbar" class="nav-menu navbar">
        <ul>
          <li><a href="<?php echo home_url(); ?>#hero" class="nav-link scrollto active"><i class="bx bx-home"></i> <span>Home</span></a></li>
          <li><a href="<?php echo home_url(); ?>#about" class="nav-link scrollto"><i class="bx bx-user"></i> <span>About</span></a></li>
          <li><a href="<?php echo home_url(); ?>#facts" class="nav-link scrollto"><i class="bx bx-user"></i> <span>Facts</span></a></li>
          <li><a href="<?php echo home_url(); ?>#skills" class="nav-link scrollto"><i class='bx bxs-brain'></i> <span>Skills</span></a></li>
          <li><a href="<?php echo home_url(); ?>#resume" class="nav-link scrollto"><i class="bx bx-file-blank"></i> <span>Resume</span></a></li>
          <li><a href="<?php echo home_url(); ?>#portfolio" class="nav-link scrollto"><i class="bx bx-book-content"></i> <span>Portfolio</span></a></li>
          <li><a href="<?php echo home_url(); ?>#services" class="nav-link scrollto"><i class="bx bx-server"></i> <span>Services</span></a></li>
          <li><a href="<?php echo home_url(); ?>#testimonials" class="nav-link scrollto"><i class="bx bx-server"></i> <span>Testimonials</span></a></li>
          <li><a href="<?php echo home_url(); ?>#contact" class="nav-link scrollto"><i class="bx bx-envelope"></i> <span>Contact</span></a></li>
        </ul>
      </nav><!-- .nav-menu -->
    </div>
  </header><!-- End Header -->