<?php
/**
 * Template Name: Home Page
 * Template Post Type: post, page
 *
 * @package WordPress
 * @subpackage Twenty_Twenty
 * @since Twenty Twenty 1.0
 */?>
<?php get_header();?>

  <!-- ======= Hero Section ======= -->

  <?php 
$labels = get_field('labels','option');
$servic = $labels['About'];
$rec = $labels['Facts'];
$wrk = $labels['works'];
$skill = $labels['Skills'];
$resume = $labels['Resume'];
$portflio = $labels['Portfolio'];
$services_ = $labels['Services'];
$testmnial = $labels['Testimonials'];
$cntct = $labels['Contact'];
// echo "<pre>";
// print_r($labels);
// echo "</pre>";
?>
  <?php 
$banner = get_field('banner','option');
$img_bg =  $banner['background_image_'];
$img_title =  $banner['title'];
$img_sbtitle =  $banner['subtitle'];
$img_animate =  $banner['animate_text'];
// echo "<pre>";
// print_r($banner);
// echo "</pre>";
?>
  <section id="hero" class="d-flex flex-column justify-content-center align-items-center" style="background: url(<?php echo $img_bg['url'];?>) top center;
">
    <div class="hero-container" data-aos="fade-in">
      <h1><?php echo $img_title;?></h1>
      <p><?php echo $img_sbtitle ;?> <span class="typed" data-typed-items="<?php echo $img_animate; ?>"></span></p>
    </div>
  </section><!-- End Hero -->

  <main id="main">

    <!-- ======= About Section ======= -->
    <section id="about" class="about">
      <?php
      $about = get_field('about_content','option');
      
      $ab_content = $about['top_content'];
      $ab_text = $about['about_text'];
      $ab_btext = $about['about_bottom_text'];
      $ab_lftimg = $about['left_image'];
      $ab_title = $about['about_title'];
      $ab_rep = $about['profile_rep'];
      // echo "<pre>";
      // print_r($ab_rep);
      // echo "</pre>";
      ?>
      <div class="container">

        <div class="section-title">
        <?php 
          if($servic):?>
          <h2><?php echo $servic; ?></h2>
          <?php 
          endif;
          ?>
          <p><?php echo $ab_content; ?></p>
        </div>

        <div class="row">
          <div class="col-lg-4" data-aos="fade-right">
            <img src="<?php echo $ab_lftimg['url']; ?>" class="img-fluid" alt="<?php echo $ab_lftimg['alt']; ?>">
          </div>
          <div class="col-lg-8 pt-4 pt-lg-0 content" data-aos="fade-left">
            <h3><?php echo $ab_title; ?></h3>
            <p class="fst-italic">
            <?php echo $ab_text; ?>
            </p>
            <div class="row">
              <div class="col-lg-12">
                <?php 
                if( $ab_rep ) {?>
                <ul class="col-2-li">
                <?php foreach( $ab_rep as $row ) {
                                        $title = $row['title__'];
                                        $nmbr_prcnt = $row['content_'];
                                    ?>
                  <li><i class="bi bi-chevron-right"></i> <strong><?php echo $title; ?>:</strong> <span><?php echo $nmbr_prcnt; ?></span></li>
                  <?php }?>
                </ul>
                <?php }?>
              </div>
            <p><?php echo $ab_btext; ?></p>
          </div>
        </div>

      </div>
    </section><!-- End About Section -->

    <!-- ======= Facts Section ======= -->
    <section id="facts" class="facts">
      <div class="container">

        <div class="section-title">
          <?php 
          if($rec):?>
          <h2><?php echo $rec; ?></h2>
          <?php 
          endif;
          ?>
          <?php 
          $facts_cntnt = get_field('fact_content','option');
          if($facts_cntnt):?>
          <p><?php echo $facts_cntnt; ?></p>
          <?php 
          endif;
          ?>
                </div>
                <?php 
          $fact_rep = get_field('facts','option');
          if( $fact_rep ) {?>
       <div class="row no-gutters">
        <?php foreach( $fact_rep as $row ) {
            $ed_icon = $row['icon'];
            $ed_counter = $row['counter'];
            $ed_title= $row['title'];

            //echo $ed_icon;
         ?>
          <div class="col-lg-3 col-md-6 d-md-flex align-items-md-stretch" data-aos="fade-up" data-aos-delay="300">
            <div class="count-box">
              <i class="<?php  echo $ed_icon;?>"></i>
              <span data-purecounter-start="0" data-purecounter-end="<?php echo $ed_counter; ?>" data-purecounter-duration="1" class="purecounter"></span>
              <p><strong><?php echo $ed_title; ?></strong></p>
            </div>
          </div>
          <?php } ?>
        </div>
        <?php } ?>
      </div>
    </section><!-- End Facts Section -->

    <!-- ======= Skills Section ======= -->
    <section id="skills" class="skills section-bg">
      <div class="container">

        <div class="section-title">
        <?php 
          if($skill):?>
          <h2><?php echo $skill; ?></h2>
          <?php 
          endif;
          ?>
          <p><?php the_field('skills_text','option');?></p>
        </div>

        <div class="row skills-content">
        <?php 
        $skill = get_field('skills_repeater','option');
        if( $skill ) {?>
          <div class="row skills-content" data-aos="fade-up">
          <?php foreach( $skill as $row ) {
                                        $title = $row['skill_name'];
                                        $nmbr_prcnt = $row['skill_percent'];
                                    ?>
            <div class="col-lg-6">
              <div class="progress">
              <span class="skill"><?php echo $title; ?> <i class="val"><?php echo $nmbr_prcnt . '%'; ?></i></span>
              <div class="progress-bar-wrap">
                <div class="progress-bar" role="progressbar" aria-valuenow="<?php echo $nmbr_prcnt; ?>" aria-valuemin="0" aria-valuemax="100"></div>
              </div>
            </div>
          </div>
          <?php }?>
          </div>
          <?php }?>

        </div>

      </div>
    </section><!-- End Skills Section -->

    <!-- ======= Resume Section ======= -->
    <section id="resume" class="resume">
      <div class="container">

        <div class="section-title">
<?php 
          if($resume):?>
          <h2><?php echo $resume; ?></h2>
          <?php 
          endif;
          ?>
           <?php 
        $res_c = get_field('resume_content_','option');
          if($res_c):?>
          <p><?php echo $res_c; ?></p>
          <?php 
          endif;
          ?>
         </div>

        <div class="row">
          <div class="col-lg-6" data-aos="fade-up">
            <h3 class="resume-title">Education</h3>
            <?php 
                             $education = get_field('education','option');
                             if( $education ) {
                             foreach( $education as $row ) {
                                        $ed_name = $row['university_name'];
                                        $ed_date = $row['date'];
                                        $ed_end_date= $row['date_end'];
                                        $ed_type = $row['type'];
                                        $ed_desc = $row['description'];
                                        $ed_certificate = $row['certificate_link'];
                                    ?>
            <div class="resume-item">
              <h4><?php echo $ed_name; ?></h4>
              <h5><?php echo $ed_date . ' - ' . $ed_end_date; ?></h5>
              <p><em><?php echo $ed_type; ?></em></p>
              <p><?php echo $ed_desc; ?></p>

              </div>
            <?php }?>
            <?php }?>
          </div>
          <div class="col-lg-6" data-aos="fade-up" data-aos-delay="100">
            <h3 class="resume-title">Professional Experience</h3>
            <?php 
                             $experiance = get_field('work_experiance','option');
                             if( $experiance ) {?>
                             <?php foreach( $experiance as $row ) {
                                        $ed_name = $row['university_name'];
                                        $ed_date = $row['date'];
                                        $ed_end_date= $row['date_end'];
                                        $ed_type1 = $row['type_'];
                                        $ed_desc = $row['description'];
                                    ?>
            <div class="resume-item">
              <h4><?php echo $ed_name; ?></h4>
              <h5><?php echo $ed_date . '-'. $ed_end_date ; ?></h5>
              <p><em><?php echo $ed_type1; ?> </em></p>
              <?php echo $ed_desc; ?>
            </div>
            <?php }?>
            <?php }?>
          </div>
        </div>

      </div>
    </section><!-- End Resume Section -->

    <!-- ======= Portfolio Section ======= -->
    <section id="portfolio" class="portfolio section-bg">
      <div class="container">

        <div class="section-title">
        <?php 
          if($portflio):?>
          <h2><?php echo $portflio; ?></h2>
          <?php 
          endif;
          ?>
          <p>Magnam dolores commodi suscipit. Necessitatibus eius consequatur ex aliquid fuga eum quidem. Sit sint consectetur velit. Quisquam quos quisquam cupiditate. Et nemo qui impedit suscipit alias ea. Quia fugiat sit in iste officiis commodi quidem hic quas.</p>
        </div>

        <div class="row" data-aos="fade-up">
          <div class="col-lg-12 d-flex justify-content-center">
            <ul id="portfolio-flters">
              <li data-filter="*" class="filter-active">All</li>
              <li data-filter=".filter-app">App</li>
              <li data-filter=".filter-card">Card</li>
              <li data-filter=".filter-web">Web</li>
            </ul>
          </div>
        </div>

        <div class="row portfolio-container" data-aos="fade-up" data-aos-delay="100">

          <div class="col-lg-4 col-md-6 portfolio-item filter-app">
            <div class="portfolio-wrap">
              <img src="http://localhost/portfolio/wp-content/themes/Portfolio-child/assets/img/portfolio/portfolio-1.jpg" class="img-fluid" alt="">
              <div class="portfolio-links">
                <a href="http://localhost/portfolio/wp-content/themes/Portfolio-child/assets/img/portfolio/portfolio-1.jpg" data-gallery="portfolioGallery" class="portfolio-lightbox" title="App 1"><i class="bx bx-plus"></i></a>
                <a href="portfolio-details.html" title="More Details"><i class="bx bx-link"></i></a>
              </div>
            </div>
          </div>

          <div class="col-lg-4 col-md-6 portfolio-item filter-web">
            <div class="portfolio-wrap">
              <img src="http://localhost/portfolio/wp-content/themes/Portfolio-child/assets/img/portfolio/portfolio-2.jpg" class="img-fluid" alt="">
              <div class="portfolio-links">
                <a href="http://localhost/portfolio/wp-content/themes/Portfolio-child/assets/img/portfolio/portfolio-2.jpg" data-gallery="portfolioGallery" class="portfolio-lightbox" title="Web 3"><i class="bx bx-plus"></i></a>
                <a href="portfolio-details.html" title="More Details"><i class="bx bx-link"></i></a>
              </div>
            </div>
          </div>

          <div class="col-lg-4 col-md-6 portfolio-item filter-app">
            <div class="portfolio-wrap">
              <img src="http://localhost/portfolio/wp-content/themes/Portfolio-child/assets/img/portfolio/portfolio-3.jpg" class="img-fluid" alt="">
              <div class="portfolio-links">
                <a href="http://localhost/portfolio/wp-content/themes/Portfolio-child/assets/img/portfolio/portfolio-3.jpg" data-gallery="portfolioGallery" class="portfolio-lightbox" title="App 2"><i class="bx bx-plus"></i></a>
                <a href="portfolio-details.html" title="More Details"><i class="bx bx-link"></i></a>
              </div>
            </div>
          </div>

          <div class="col-lg-4 col-md-6 portfolio-item filter-card">
            <div class="portfolio-wrap">
              <img src="http://localhost/portfolio/wp-content/themes/Portfolio-child/assets/img/portfolio/portfolio-4.jpg" class="img-fluid" alt="">
              <div class="portfolio-links">
                <a href="http://localhost/portfolio/wp-content/themes/Portfolio-child/assets/img/portfolio/portfolio-4.jpg" data-gallery="portfolioGallery" class="portfolio-lightbox" title="Card 2"><i class="bx bx-plus"></i></a>
                <a href="portfolio-details.html" title="More Details"><i class="bx bx-link"></i></a>
              </div>
            </div>
          </div>

          <div class="col-lg-4 col-md-6 portfolio-item filter-web">
            <div class="portfolio-wrap">
              <img src="http://localhost/portfolio/wp-content/themes/Portfolio-child/assets/img/portfolio/portfolio-5.jpg" class="img-fluid" alt="">
              <div class="portfolio-links">
                <a href="http://localhost/portfolio/wp-content/themes/Portfolio-child/assets/img/portfolio/portfolio-5.jpg" data-gallery="portfolioGallery" class="portfolio-lightbox" title="Web 2"><i class="bx bx-plus"></i></a>
                <a href="portfolio-details.html" title="More Details"><i class="bx bx-link"></i></a>
              </div>
            </div>
          </div>

          <div class="col-lg-4 col-md-6 portfolio-item filter-app">
            <div class="portfolio-wrap">
              <img src="http://localhost/portfolio/wp-content/themes/Portfolio-child/assets/img/portfolio/portfolio-6.jpg" class="img-fluid" alt="">
              <div class="portfolio-links">
                <a href="http://localhost/portfolio/wp-content/themes/Portfolio-child/assets/img/portfolio/portfolio-6.jpg" data-gallery="portfolioGallery" class="portfolio-lightbox" title="App 3"><i class="bx bx-plus"></i></a>
                <a href="portfolio-details.html" title="More Details"><i class="bx bx-link"></i></a>
              </div>
            </div>
          </div>

          <div class="col-lg-4 col-md-6 portfolio-item filter-card">
            <div class="portfolio-wrap">
              <img src="http://localhost/portfolio/wp-content/themes/Portfolio-child/assets/img/portfolio/portfolio-7.jpg" class="img-fluid" alt="">
              <div class="portfolio-links">
                <a href="http://localhost/portfolio/wp-content/themes/Portfolio-child/assets/img/portfolio/portfolio-7.jpg" data-gallery="portfolioGallery" class="portfolio-lightbox" title="Card 1"><i class="bx bx-plus"></i></a>
                <a href="portfolio-details.html" title="More Details"><i class="bx bx-link"></i></a>
              </div>
            </div>
          </div>

          <div class="col-lg-4 col-md-6 portfolio-item filter-card">
            <div class="portfolio-wrap">
              <img src="http://localhost/portfolio/wp-content/themes/Portfolio-child/assets/img/portfolio/portfolio-8.jpg" class="img-fluid" alt="">
              <div class="portfolio-links">
                <a href="http://localhost/portfolio/wp-content/themes/Portfolio-child/assets/img/portfolio/portfolio-8.jpg" data-gallery="portfolioGallery" class="portfolio-lightbox" title="Card 3"><i class="bx bx-plus"></i></a>
                <a href="portfolio-details.html" title="More Details"><i class="bx bx-link"></i></a>
              </div>
            </div>
          </div>

          <div class="col-lg-4 col-md-6 portfolio-item filter-web">
            <div class="portfolio-wrap">
              <img src="http://localhost/portfolio/wp-content/themes/Portfolio-child/assets/img/portfolio/portfolio-9.jpg" class="img-fluid" alt="">
              <div class="portfolio-links">
                <a href="http://localhost/portfolio/wp-content/themes/Portfolio-child/assets/img/portfolio/portfolio-9.jpg" data-gallery="portfolioGallery" class="portfolio-lightbox" title="Web 3"><i class="bx bx-plus"></i></a>
                <a href="portfolio-details.html" title="More Details"><i class="bx bx-link"></i></a>
              </div>
            </div>
          </div>

        </div>

      </div>
    </section><!-- End Portfolio Section -->

    <!-- ======= Services Section ======= -->
    <section id="services" class="services">
      <div class="container">

        <div class="section-title">
        <?php 
          if($services_):?>
          <h2><?php echo $services_; ?></h2>
          <?php 
          endif;
          ?>

          <?php 
          $service_cntnt = get_field('services_content','option');
          if($service_cntnt):?>
          <p><?php echo $service_cntnt; ?></p>
          <?php 
          endif;
          ?>
        </div>
        <?php 
          $ser_rep = get_field('our_services','option');
          if( $ser_rep ) {?>
        <div class="row">
        <?php foreach( $ser_rep as $row ) {
            $ed_icon = $row['service_icon'];
            $ed_title = $row['service_title'];
            $ed_text= $row['service_text'];
         ?>
          <div class="col-lg-4 col-md-6 icon-box" data-aos="fade-up" data-aos-delay="500">
            <div class="icon"><i class="<?php echo $ed_icon; ?>"></i></div>
            <h4 class="title"><a href=""><?php echo $ed_title; ?></a></h4>
            <p class="description"><?php echo $ed_text; ?></p>
          </div>
          <?php }?>
        </div>
        <?php }?>

      </div>
    </section><!-- End Services Section -->

    <!-- ======= Testimonials Section ======= -->
    <section id="testimonials" class="testimonials section-bg">
      <div class="container">

        <div class="section-title">
        <?php 
          if($testmnial):?>
          <h2><?php echo $testmnial; ?></h2>
          <?php 
          endif;
          ?>
          <p><?php the_field('testimonial_text','option');?></p>
        </div>

        <div class="testimonials-slider swiper" data-aos="fade-up" data-aos-delay="100">
        <?php 
                             $reviews = get_field('reviews','option');
                             if( $reviews ) {?>
          <div class="swiper-wrapper">
          <?php foreach( $reviews as $row ) {
                                        $name = $row['name'];
                                        $desg = $row['designation'];
                                        $p_img = $row['profile_image'];
                                        //$rating = $row['rating'];
                                        $rev_txt = $row['review_text'];
                                    ?>
                                                <div class="swiper-slide">
              <div class="testimonial-item" data-aos="fade-up" data-aos-delay="400"> 
              <p>
                  <i class="bx bxs-quote-alt-left quote-icon-left"></i>
                  <?php echo $rev_txt; ?>
                  <i class="bx bxs-quote-alt-right quote-icon-right"></i>
                </p>
                 <img src="<?php echo $p_img['url'];?>" class="testimonial-img" alt="">
                <h3><?php echo $name; ?></h3>
                <h4><?php echo $desg; ?></h4>
              </div>
            </div><!-- End testimonial item -->
            <?php }?>
          </div>
          <?php }?>
          <div class="swiper-pagination"></div>
        </div>

      </div>
    </section><!-- End Testimonials Section -->

    <!-- ======= Contact Section ======= -->
    <section id="contact" class="contact">
      <div class="container">

        <div class="section-title">
        <?php 
          if($cntct):?>
          <h2><?php echo $cntct; ?></h2>
          <?php 
          endif;
          ?>

<?php 
$contact_info = get_field('contact_info','option');
$contact_rdnc = $contact_info['Location'];
$contact_city = $contact_info['Email'];
$contact_age = $contact_info['Call'];
$contact_data = $contact_info['contact_data'];
$contact_map = $contact_info['map'];

// echo "<pre>";
// print_r($contact_info);
// echo "</pre>";
?>
 <?php if($contact_rdnc):?>


          <p><?php echo $contact_data; ?></p>        </div>

        <div class="row" data-aos="fade-in">

          <div class="col-lg-5 d-flex align-items-stretch">
            <div class="info">
              <div class="address">
                <i class="bi bi-geo-alt"></i>
                <h4>Location:</h4>
                <p><?php echo $contact_rdnc; ?></p>
              </div>

              <div class="email">
                <i class="bi bi-envelope"></i>
                <h4>Email:</h4>
                <p><?php echo $contact_city; ?></p>
              </div>

              <div class="phone">
                <i class="bi bi-phone"></i>
                <h4>Call:</h4>
                <p><?php echo $contact_age; ?></p>
              </div>

              <iframe src="<?php echo $contact_map; ?>" frameborder="0" style="border:0; width: 100%; height: 290px;" allowfullscreen></iframe>
            </div>

          </div>

          <div class="col-lg-7 mt-5 mt-lg-0 d-flex align-items-stretch">
            <form action="http://localhost/portfolio/wp-content/themes/Portfolio-child/forms/contact.php" method="post" role="form" class="php-email-form">
              <div class="row">
                <div class="form-group col-md-6">
                  <label for="name">Your Name</label>
                  <input type="text" name="name" class="form-control" id="name" required>
                </div>
                <div class="form-group col-md-6">
                  <label for="name">Your Email</label>
                  <input type="email" class="form-control" name="email" id="email" required>
                </div>
              </div>
              <div class="form-group">
                <label for="name">Subject</label>
                <input type="text" class="form-control" name="subject" id="subject" required>
              </div>
              <div class="form-group">
                <label for="name">Message</label>
                <textarea class="form-control" name="message" rows="10" required></textarea>
              </div>
              <div class="my-3">
                <div class="loading">Loading</div>
                <div class="error-message"></div>
                <div class="sent-message">Your message has been sent. Thank you!</div>
              </div>
              <div class="text-center"><button type="submit">Send Message</button></div>
            </form>
            <?php //echo do_shortcode('[contact-form-7 id="" title="My Contact Form"]');?>
          </div>

        </div>
        <?php endif; ?>

      </div>
    </section><!-- End Contact Section -->
    <footer id="footer">
    <div class="container container d-flex justify-content-center">
      <div class="copyright">
      <?php the_field('privacy_text','option');?>
      </div>
      <div class="footer-link">Email: <a href="<?php echo esc_url( 'mailto:' . antispambot( get_field('email','option' ) ) ); ?>"><?php echo esc_html( antispambot( get_field('email','option' ) ) ); ?></a>
</div>
      </div>
    </div>
  </footer>
  </main><!-- End #main -->
  
  <?php get_footer();?>