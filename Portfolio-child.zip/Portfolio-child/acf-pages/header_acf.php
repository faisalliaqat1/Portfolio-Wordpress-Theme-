<?php
if( function_exists('acf_add_options_page') ) {
    
    acf_add_options_page(array(
        'page_title'    => 'Theme Setting',
        'menu_title'    => 'Theme Settings',
        'menu_slug'     => 'theme-settings',
        'capability'    => 'edit_posts',
        'redirect'      => false
    ));

    acf_add_options_sub_page(array(
        'page_title'    => 'Side Bar',
        'menu_title'    => 'Side Bar',
        'parent_slug'   => 'theme-settings',
    ));
    acf_add_options_sub_page(array(
        'page_title'    => 'Banner',
        'menu_title'    => 'Banner',
        'parent_slug'   => 'theme-settings',
    ));
    
    acf_add_options_sub_page(array(
        'page_title'    => 'About',
        'menu_title'    => 'About',
        'parent_slug'   => 'theme-settings',
    ));
    acf_add_options_sub_page(array(
        'page_title'    => 'Facts',
        'menu_title'    => 'Facts',
        'parent_slug'   => 'theme-settings',
    ));
    
    acf_add_options_sub_page(array(
        'page_title'    => 'Footer Settings',
        'menu_title'    => 'Footer',
        'parent_slug'   => 'theme-settings',
    ));
    acf_add_options_sub_page(array(
        'page_title'    => 'Label',
        'menu_title'    => 'Labels',
        'parent_slug'   => 'theme-settings',
    ));

    acf_add_options_sub_page(array(
        'page_title'    => 'Review',
        'menu_title'    => 'Reviews',
        'parent_slug'   => 'theme-settings',
    ));
    acf_add_options_sub_page(array(
        'page_title'    => 'Resume',
        'menu_title'    => 'Resume',
        'parent_slug'   => 'theme-settings',
    ));
    acf_add_options_sub_page(array(
        'page_title'    => 'Services',
        'menu_title'    => 'Services',
        'parent_slug'   => 'theme-settings',
    ));
}
    